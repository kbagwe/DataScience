# Visual_Analytics_Project

This project was created in order to help interpret data collected on Covid19 in the United States.
The project covers issues on cases, deaths, and vaccinations in the US.

Application URL :: https://va-covid-st.herokuapp.com/


Sources for this project are from another github repository and the CDC (Centers for Disease Control and Prevention). You can use the links below for more information on where the data was collected.




https://github.com/CSSEGISandData/COVID-19

https://data.cdc.gov/Case-Surveillance/United-States-COVID-19-Cases-and-Deaths-by-State-o/9mfq-cb36/data

https://covid.cdc.gov/covid-data-tracker/?CDC_AA_refVal=https%3A%2F%2Fwww.cdc.gov%2Fcoronavirus%2F2019-ncov%2Fcases-updates%2Fcases-in-us.html#vaccination-trends
